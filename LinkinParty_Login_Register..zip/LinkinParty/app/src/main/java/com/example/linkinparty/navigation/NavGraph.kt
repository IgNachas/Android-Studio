package com.example.linkinparty.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.linkinparty.ui.screen.LoginScreenVm
import com.example.linkinparty.ui.screen.RegistScreenVm
import kotlinx.coroutines.launch

@Composable
fun AppNavGraph(navController: NavHostController) {

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val goHome: () -> Unit    = { navController.navigate(Route.main.path) }
    val goLogin: () -> Unit   = { navController.navigate(Route.Login.path) }
    val goRegister: () -> Unit = { navController.navigate(Route.Register.path) }

    Scaffold(
    ){innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Route.Login.path,
            modifier = Modifier.padding(innerPadding)
        ){
            composable(Route.Login.path){
                LoginScreenVm(
                    onLogNavigateHome = goHome,
                    onGoRegister = goRegister
                )
            }
            composable(Route.Register.path){
                RegistScreenVm(
                  onRegistNavigateLogin = goLogin,
                    onGoLogin = goLogin
                )
            }
        }

    }
}