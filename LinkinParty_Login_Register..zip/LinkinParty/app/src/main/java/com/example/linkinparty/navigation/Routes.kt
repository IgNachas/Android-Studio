package com.example.linkinparty.navigation

sealed class Route(val path: String) { // Cada objeto representa una pantalla
    data object Login    : Route("login")
    data object Register : Route("register")
    data object main     : Route("main")
}