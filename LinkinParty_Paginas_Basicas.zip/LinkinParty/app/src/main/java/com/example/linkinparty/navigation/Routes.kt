package com.example.linkinparty.navigation

sealed class Route(val path: String) { // Cada objeto representa una pantalla
    data object Login    : Route("login")
    data object Register : Route("register")
    data object Main     : Route("main")

    data object  User    : Route("User")

    data object Create   : Route("Create")

    data object Invitation : Route("Invitation")

    data object Notification : Route("Notification")
}