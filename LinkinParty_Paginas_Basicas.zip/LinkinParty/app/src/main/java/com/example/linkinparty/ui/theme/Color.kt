package com.example.linkinparty.ui.theme

import androidx.compose.ui.graphics.Color

val AzulSuave = Color(0xFF8ECAE6)
val CyanFuerte = Color(0xFF219EBC)
val VividNaranja = Color(0xFFFFB703)
val NaranjaPuro = Color(0xFFFB8500)

val AzulMuyOscuro = Color(0xFF023047)
val CyanOscuroModerado = Color(0xFF2A6E78)

val FondoClaro = Color(0xFFE8F0F1)
val FondoOscuro = Color(0xFF121212)