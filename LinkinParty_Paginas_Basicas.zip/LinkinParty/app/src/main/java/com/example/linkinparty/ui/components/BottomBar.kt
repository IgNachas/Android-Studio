package com.example.linkinparty.ui.components

import android.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.LocalPlay
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.BottomAppBarDefaults
import androidx.compose.material3.BottomAppBarState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppBottomBar(
    onMain: () -> Unit,
    onNotification: () -> Unit,
    onCreate: () -> Unit,
    onInvitation: () -> Unit,
    onUser: () -> Unit
){
    BottomAppBar {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Center
            ) {
            IconButton(onClick = onMain) {
                Icon(Icons.Filled.LocalPlay, contentDescription = "Main")
            }
            IconButton(onClick = onNotification) {
                Icon(Icons.Filled.Notifications, contentDescription = "Noti")
            }
            IconButton(onClick = onCreate) {
                Icon(Icons.Filled.AddBox, contentDescription = "Create")
            }
            IconButton(onClick = onInvitation) {
                Icon(Icons.Filled.Mail, contentDescription = "Invi")
            }
            IconButton(onClick = onUser) {
                Icon(Icons.Filled.AccountBox, contentDescription = "User")
            }
        }
    }
}