package com.example.linkinparty.navigation

import UserScreen
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.linkinparty.ui.components.AppBottomBar
import com.example.linkinparty.ui.screen.CreateScreen
import com.example.linkinparty.ui.screen.InviScreen
import com.example.linkinparty.ui.screen.LoginScreenVm
import com.example.linkinparty.ui.screen.MainScreen
import com.example.linkinparty.ui.screen.NotiScreen
import com.example.linkinparty.ui.screen.RegistScreenVm
import kotlinx.coroutines.launch

@Composable
fun AppNavGraph(navController: NavHostController) {

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val goMain: () -> Unit    = { navController.navigate(Route.Main.path) }
    val goLogin: () -> Unit   = { navController.navigate(Route.Login.path) }
    val goRegister: () -> Unit = { navController.navigate(Route.Register.path) }

    val goUSer: () -> Unit = {navController.navigate(Route.User.path)}
    val goNoti: () -> Unit = {navController.navigate(Route.Notification.path)}
    val goCreate: () -> Unit = {navController.navigate(Route.Create.path)}
    val goInvit:  () -> Unit = {navController.navigate(Route.Invitation.path)}

    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            if (currentRoute != Route.Login.path && currentRoute != Route.Register.path) {
                AppBottomBar(
                    onMain = goMain,
                    onNotification = goNoti,
                    onCreate = goCreate,
                    onInvitation = goInvit,
                    onUser = goUSer
                )
            }
        }
    ){innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Route.Login.path,
            modifier = Modifier.padding(innerPadding)
        ){
            composable(Route.Login.path){
                LoginScreenVm(
                    onLogNavigateHome = goMain,
                    onGoRegister = goRegister
                )
            }
            composable(Route.Register.path){
                RegistScreenVm(
                  onRegistNavigateLogin = goLogin,
                    onGoLogin = goLogin
                )
            }
            composable (Route.Main.path){
                MainScreen(
                    onGoInvi = goInvit,
                    onGoCreate = goCreate
                )
            }

            composable (Route.User.path){
                UserScreen(
                    onGoMain = goMain
                )
            }

            composable (Route.Notification.path){
                NotiScreen(
                    onGoMain = goMain
                )
            }

            composable (Route.Create.path){
                CreateScreen(
                    onGoMain = goMain
                )
            }

            composable (Route.Invitation.path){
               InviScreen(
                   onGoMain = goMain
               )
            }
        }

    }
}